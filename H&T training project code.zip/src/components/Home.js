import React from "react";
import './Home.css'
import { Link } from "react-router-dom";
import  Carousel  from 'react-bootstrap/Carousel';
import carousel_1 from '../images/carousel_1.jpg';
import carousel_2  from '../images/carousel_2.jpg';
import carousel_3  from '../images/carousel_3.jpg';
//import Navigation from "./Navigation";
const Home=()=>{
   
    return(
       <>
            <div className=' homeclass ui comments four column grid very relaxed'>
            <Carousel slide={false}>

                <Carousel.Item>

                    <img style={{height:"400px"}}

                        className="d-block w-100"

                        src={carousel_1}

                        alt="First slide"

                    />

                    <Carousel.Caption className="captionimage">

                        <h3 >First slide label</h3>

                        <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>

                    </Carousel.Caption>

                </Carousel.Item>

                <Carousel.Item>

                    <img style={{height:"400px"}}

                        className="d-block w-100"

                        src={carousel_2}

                        alt="Second slide"

                    />

                    <Carousel.Caption className="captionimage">

                        <h3>Second slide label</h3>

                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>

                    </Carousel.Caption>

                </Carousel.Item>

                <Carousel.Item>

                    <img style={{height:"400px"}}

                        className="d-block w-100"

                        src={carousel_3}

                        alt="Third slide"

                    />

                    <Carousel.Caption className="captionimage">

                        <h3>Third slide label</h3>

                        <p>

                            Praesent commodo cursus magna, vel scelerisque nisl consectetur.

                        </p>

                    </Carousel.Caption>

                </Carousel.Item>

            </Carousel>
            <div class="container-fluid" style={{position:"absolute", bottom:'3rem'}}>
            <div class="row">
                <div class="col-md-1 offset-md-3 col-sm-4 col-4">
               <button type="button" className="btnclass" ><Link to="/jobs" className="linkstyle">Jobs</Link></button>
               </div>
               <div class="col-md-1 offset-md-1 col-sm-4 col-4">
               <button type="button" href="/contactus" className="btnclass" ><Link to="/contactus" className="linkstyle">ContactUs</Link></button>
               </div>
               <div class="col-md-1 offset-md-1 col-sm-4 col-4">
               <button type="button" className="btnclass" ><Link to="/comingsoon" className="linkstyle">ComingSoon</Link></button>
                </div>
            </div>
            </div>
            </div>
            
         
        </>
    ) 
   
}
export default Home
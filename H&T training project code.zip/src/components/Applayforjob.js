import React, {useState } from "react";
import { useParams } from "react-router-dom";
import "./Applayforjob.css";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { applyJobs } from "../redux/JobActions";

const Applayforjob = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm();
  const params = useParams();
  const [userInfo, setUserInfo] = useState({
    JobId: params.id,
  });
  let dispatch = useDispatch();

//form submission method
  const onSubmit = (data) => {
    console.log("form data", data);
    setUserInfo(data);
    dispatch(applyJobs({ JobId: params.id, ...data }));
    reset()
  };

  console.log(errors);
  
  return (
    <>
      <div class="container">
        <div class="row" style={{ position: "relative", top: "3rem" }}>
          <div class="col-12">
            <p className="titlestyle">Apply For Job</p>
            <pre>{JSON.stringify(userInfo, undefined, 2)}</pre>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div class="form-group">
                <input
                  type="text"
                  class="form-control inputsapce"
                  id="exampleInputname"
                  aria-describedby="emailHelp"
                  name="usernmae"
                  placeholder="Name"
                  {...register("username", {
                    required: "Username is required",
                    minLength:{
                      value:4,
                    message:"Username should contain four characters",
                    },
                    maxLength:{
                      value:10,
                      message:"username is to long",
                    }
                  })}
                ></input>
              </div>
              <p className="dangerclass">{errors.username &&(errors.username.message)}</p>
              
              <div class="form-group">
                <input
                  type="email"
                  class="form-control inputsapce"
                  id="exampleInputEmail1"
                  {...register("email", { required: "Email is required",
                  pattern:{
                    value:/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/g,
                    message:"Invalid email address"
                  }
                 })}
                  name="email"
                  aria-describedby="emailHelp"
                  placeholder="Enter email"
                ></input>
              </div>
              <p className="dangerclass">{errors.email &&(errors.email.message)}</p>
              

              <div class="form-group">
                <input
                  type="number"
                  class="form-control inputsapce"
                  id="exampleInputPassword1"
                  {...register("mobilenumber", {
                    required: "MobileNumber is required",
                    pattern:{
                      value:/^(\+\d{1,3}[- ]?)?\d{10}$/,
                      message:"Invalid phone number"
                    }
                  })}
                  name="mobilenumber"
                  placeholder="Enter mobile number"
                ></input>
              </div>
             <p className="dangerclass">{errors.mobilenumber &&(errors.mobilenumber.message)}</p>
             
              <div class="form-group">
                <input
                  type="text"
                  class="form-control inputsapce"
                  id="exampleInputPassword1"
                  {...register("experiance", {
                    required: "Experiance is required",
                  })}
                  name="experiance"
                  placeholder="Experiance"
                ></input>
              </div>
              <p className="dangerclass">{errors.experiance &&(errors.experiance.message)}</p>
              
              <button
                type="submit"
                class="btn btn-success col-lg-12 col-12"
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};
export default Applayforjob;

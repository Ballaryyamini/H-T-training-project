import React from "react";

const ComingSoon=()=>{
    return (
        <>
        <h5 class="g31">Front end Developer</h5>

<h5 class="mt-auto p-1">java Developer  </h5>
<p class="card-text">location: chennai</p>
<p class="card-text">Experience:3-4 years</p>
<p class="card-text">skills : HTML,CSS,java</p>

<h5 class="g31">SAP Fico</h5>
<h5 class="mt-auto p-1">System Analyst </h5>
<p class="card-text">location: hyderabad</p>
<p class="card-text">Experience:1-6 years</p>
<p class="card-text">skills : Sap data Migration, ADM, Finance</p>

<h5 class="g31"> Test Engineer</h5>
<h5 class="mt-auto p-1">Program Analyst </h5>
<p class="card-text">location: hyderabad,chennai,Bangalore</p>
<p class="card-text">Experience:3-5 years</p>
<p class="card-text">skills : Test engineering,java,selenium, QA testing, node js</p>


        </>
    )
}
export default ComingSoon